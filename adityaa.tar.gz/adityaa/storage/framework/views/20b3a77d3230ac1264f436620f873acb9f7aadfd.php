<!doctype html>

<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" type="text/css" href="css/app.css" >
        <title>Posts</title>
        

       
    </head>
    <body>
        <?php echo $__env->make('inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="jumbotron text-center">
            
     <h1><?php echo e($post->title); ?></h1>
        <small>Created  <?php echo e($post->created_at); ?> by  <?php echo e($post->user->name); ?> Category <?php echo e($post->category); ?></small>
             <img style="width:100%" src="/storage/cover_images/<?php echo e($post->cover_image); ?>">
    <br><br>
        <div>
            <?php echo $post->body; ?>

            
        </div>
            <a href="/posts" class="btn btn-default">Back</a>
            <?php if(!Auth::guest()): ?>
              <?php if(Auth::user()->id==$post->user_id): ?>
            <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-default">Edit</a>
            <hr>
          
            <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

            <?php endif; ?>
        <?php endif; ?>    
               
        </div>
        
    </body>
</html>
<?php echo $__env->make('layouts.myblog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>