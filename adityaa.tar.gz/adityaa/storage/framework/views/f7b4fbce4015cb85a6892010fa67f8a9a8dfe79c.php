<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="css/app.css" >

        <title>Adityaa Chaubey Blog</title>


    </head>
    <body>
         <?php echo $__env->make('inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <center><h1>About</h1>
            <br>
            <hr>
            <h4><i>My name is Adityaa Chaubey. I made this blog.
            I recently completed my B.Tech in Computer Science Engineering with specialization in Mainframe Technology at University of Petroleum & Engineering Studies, Dehradun. I am fortified with the ability of sound verbal and written communication skills and the ability to work under pressure and I am a quick learner. I have got good programming skills and a grip over languages such as JAVA, C & C++, and C ,HTML, CSS, JavaScript, Angular JS, Scala and PHP(Laravel). I have sound knowledge of databases i.e., MySQL, MSSQL Server, DB2, Mongodb, postgresql and ORACLE. I can work on Z/OS, Windows and Linux (UBUNTU) Operating Systems. My emphasis is on full stack development, web designing, front end and database handling. I am willing to get good opportunities to work. 
                </i></h4>
            <hr>
       </center>
    </body>
</html>
