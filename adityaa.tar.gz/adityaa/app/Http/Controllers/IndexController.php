<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IndexController extends Controller
{
    public function sayhello(){
        return "Hello I am Adityaa chaubey";
    }
}
