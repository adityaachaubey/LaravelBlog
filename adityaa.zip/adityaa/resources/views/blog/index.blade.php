@extends('layouts.app')


@section('content')

    <div class="jumbotron text-center">
        <h1>Adityaa Chaubey Bog</h1>
        <p>Hello Bloggers!!!</p>
        <p><a class="btn btn-primary btn-lg" href="/login" role="button">Login</a> <a class="btn btn-primary btn-lg" href="/register" role="button">Register</a></p>
    </div>
@endsection