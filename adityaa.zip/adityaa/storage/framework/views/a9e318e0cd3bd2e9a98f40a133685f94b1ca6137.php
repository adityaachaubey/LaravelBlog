<!doctype html>

<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" type="text/css" href="css/app.css" >
        <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
  

        <title>Posts</title>

       
    </head>
    <body>
        <?php echo $__env->make('inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <h1>Create Posts</h1>
        <?php echo Form::open(['action' => 'PostsController@store', 'method'=>'POST','enctype'=>'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('title','Title')); ?>

 <?php echo e(Form::text('title','',['class'=>'form-control','placeholder'=>'Enter Title'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('category','Category')); ?>  Food<?php echo e(Form::radio('category', 'Food')); ?>  Dance<?php echo e(Form::radio('category', 'Dance', true)); ?>  Culture<?php echo e(Form::radio('category', 'Culture', true)); ?>

        </div>
        
 <div class="form-group">
         <?php echo e(Form::label('body','Body')); ?>

 <?php echo e(Form::textarea('body','',['id'=>'article-ckeditor','class'=>'form-control','placeholder'=>'Enter Body'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::file('cover_image')); ?></div>
    <?php echo e(Form::Submit('Submit',['class'=>"btn btn-primary"])); ?>

    
<?php echo Form::close(); ?>

        
        <script>
        CKEDITOR.replace( 'article-ckeditor' );
    </script>
    </body>
</html>
<?php echo $__env->make('layouts.myblog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>